class Carte():
    def __init__(self, id, titlu, autor, descriere):
        self.__id = id
        self.__titlu = titlu
        self.__autor = autor
        self.__descriere = descriere

    def __eq__(self, other):
        return self.__id == other.get_id() and self.__autor == other.get_autor() and self.__titlu == other.get_titlu() and self.__descriere == other.get_descriere()

    def __str__(self):
        s = ""
        s += "[ID]: " + str(self.__id) + " | "
        s += "[TITLU]: " + self.__titlu + " | "
        s += "[AUTOR]: " + self.__autor + " | "
        s += "[DESC.]: " + self.__descriere
        return s

    def get_id(self):
        return self.__id

    def get_titlu(self):
        return self.__titlu

    def get_autor(self):
        return self.__autor

    def get_descriere(self):
        return self.__descriere