from Testing.test import Tests

from Repository.client_repository import ClientRepository
from Repository.carte_repository import CarteRepository
from Repository.enrollmen_repository import EnrollmentRepository

from Validation.client_validator import ClientValidator
from Validation.carte_validator import CarteValidator
from Validation.enroll_validator import EnrollmentValidator

from Service.client_service import ClientService
from Service.carte_service import CarteService
from Service.enrollment_service import EnrollmentService

from Console.ui import Console

teste = Tests()
repo_client = ClientRepository()
repo_carte = CarteRepository()
repo_enroll = EnrollmentRepository()

valid_client = ClientValidator()
valid_carte = CarteValidator()
valid_enroll = EnrollmentValidator()

service_client = ClientService(valid_client, repo_client)
service_carte = CarteService(valid_carte, repo_carte)
service_enroll = EnrollmentService(valid_enroll, repo_enroll, service_client, service_carte)

console = Console(service_client, service_carte, service_enroll)

teste.run_all_tests()

console.run()